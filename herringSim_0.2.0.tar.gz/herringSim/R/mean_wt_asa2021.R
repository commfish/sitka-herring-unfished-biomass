#' Weight-at-age 1979-2021
#'
#' Weight-at-age (grams) estimates from 1979 to 2021 from age-weight-length sampling
#' in Sitka sound.
"mean_wt_asa2021"
