#' Catch-at-age 1976-2022
#'
#' Catch-at-age for Sitka Sound herring fishery from ASA 2023-forecast
"caa_asa2023_forecast"
