#' Survival 1973-1996
#'
#' Proportional survival estimates from 1973 to 1996 from ASA 1996. Note that
#' survivals are reported by age class, but are constant across age classes.
"S_asa1996"
