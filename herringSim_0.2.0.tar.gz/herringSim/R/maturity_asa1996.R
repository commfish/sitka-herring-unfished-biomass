#' Maturity-at-age 1973-1996
#'
#' Proportional maturity-at-age estimates from 1973 to 1996 from ASA 1996.
"maturity_asa1996"
