#' Survival 1976-2022
#'
#' Proportional survival estimates from 1976 to 2022 from ASA 2023-forecast. Note that
#' survivals are reported by age class, but are constant across age classes.
"S_asa2023_forecast"
