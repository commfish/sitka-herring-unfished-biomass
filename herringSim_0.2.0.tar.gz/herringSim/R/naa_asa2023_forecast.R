#' Numbers-at-age 1976-2022
#'
#' Numbers-at-age for Sitka Sound herring fishery from ASA 2023-forecast
"naa_asa2023_forecast"
