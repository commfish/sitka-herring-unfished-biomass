#' Maturity-at-age 1976-2022
#'
#' Proportional maturity-at-age estimates from 1976 to 2022 from ASA 2023-forecast.
"maturity_asa2023_forecast"
