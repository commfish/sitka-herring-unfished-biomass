#' Catch-at-age 1979-2021
#'
#' Catch-at-age for Sitka Sound herring fishery from ASA 2022-forecast
"caa_asa2021"
