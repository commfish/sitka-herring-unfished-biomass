#' Weight-at-age 1973-1996
#'
#' Weight-at-age (grams) estimates from 1973 to 1996 from age-weight-length sampling
#' in Sitka sound.
"mean_wt_asa1996"
