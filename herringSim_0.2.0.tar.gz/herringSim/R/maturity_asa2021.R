#' Maturity-at-age 1979-2021
#'
#' Proportional maturity-at-age estimates from 1979 to 2021 from ASA 2022-forecast.
"maturity_asa2021"
