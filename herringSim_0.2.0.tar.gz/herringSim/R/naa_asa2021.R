#' Numbers-at-age 1979-2021
#'
#' Numbers-at-age for Sitka Sound herring fishery from ASA 2022-forecast
"naa_asa2021"
