#' herringSim Color Palette
#'
#' Custom color palatte used in herringSim graphics and analysis
"cols"

