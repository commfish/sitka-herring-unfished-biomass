#' Survival 1979-2021
#'
#' Proportional survival estimates from 1979 to 2021 from ASA 2022-forecast. Note that
#' survivals are reported by age class, but are constant across age classes.
"S_asa2021"
