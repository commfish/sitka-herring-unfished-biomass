#' Weight-at-age 1976-2022
#'
#' Weight-at-age (grams) estimates from 1976 to 2022 from age-weight-length sampling
#' in Sitka sound.
"mean_wt_asa2023_forecast"
